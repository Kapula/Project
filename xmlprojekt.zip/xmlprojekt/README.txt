Poštovani/a kolega/kolegice.

Moj projekt iz kolegija XML programiranje se sastoji od Login i Sing up forme.
Radio sam pomoću ovih jezika: PHP, XML, JavaScript, HTML, CSS
U .zip fileu imate kratki video kako i na koji način forma funkcionira.

Hvala na pažnji.